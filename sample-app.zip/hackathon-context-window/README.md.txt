# TrueContext AI - Enterprise Document Intelligence Platform

## Overview
Production-grade full-stack application demonstrating side-by-side comparison between standard RAG and TrueContext AI (quality-first architecture with budget optimization).

## Architecture
- **Frontend**: React 18.3+ with TypeScript, Vite, TailwindCSS, shadcn/ui
- **API Gateway**: Node.js + Express (Port 3001)
- **AI Engine**: Python + FastAPI (Port 8000)
- **Databases**: SQLite, Neo4j, FAISS

## Quick Start

### Prerequisites
- Node.js v22.15.1+
- Python 3.12.8+
- Docker (for Neo4j)
- Azure OpenAI API access

### Installation

#### 1. Start Neo4j
```bash
docker-compose up -d
```

#### 2. Backend - Python AI Engine
```bash
cd backend-python
python3.12 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your API keys
uvicorn app.main:app --reload --port 8000
```

#### 3. Backend - Node.js API Gateway
```bash
cd backend-node
npm install
cp .env.example .env
npm run dev
```

#### 4. Frontend
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Access the application at: http://localhost:5173

## Key Features

### 1. Quality-First RAG
- 6-dimension quality validation
- Automatic context optimization
- Budget-aware token allocation

### 2. Side-by-Side Comparison
- Standard RAG vs TrueContext
- Real-time metrics
- Visual quality dashboard

### 3. Insurance Quote Generation
- Policy analysis
- Loss runs processing
- Professional PDF generation

## Documentation
See `/docs` for detailed architecture and implementation guides.

