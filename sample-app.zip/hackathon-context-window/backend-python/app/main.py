"""
TrueContext AI - FastAPI Main Application
"""
from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional, Dict
import os
import uuid
import shutil
from datetime import datetime

from app.config import settings
from app.database.sqlite_db import get_db_manager
from app.database.neo4j_db import get_graph_store
from app.core.vector_store import get_vector_store
from app.core.embeddings_service import get_embeddings_service
from app.core.llm_service import get_llm_service
from app.core.document_processor import get_document_processor
from app.core.truecontext_rag import TrueContextRAG
from app.core.standard_rag import StandardRAG, ComparisonEngine

# Initialize FastAPI app
app = FastAPI(
    title="TrueContext AI",
    description="Quality-First RAG with Budget Optimization",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify allowed origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize services
db_manager = get_db_manager(settings.database_url)
graph_store = get_graph_store(settings.neo4j_uri, settings.neo4j_user, settings.neo4j_password)
vector_store = get_vector_store()
embeddings_service = get_embeddings_service(settings.azure_openai_endpoint, settings.azure_openai_api_key)
llm_service = get_llm_service(settings.azure_openai_endpoint, settings.azure_openai_api_key)
document_processor = get_document_processor()

# Initialize RAG systems
truecontext_rag = TrueContextRAG(
    vector_store=vector_store,
    graph_store=graph_store,
    llm_service=llm_service,
    embeddings_service=embeddings_service,
    quality_threshold=settings.quality_threshold,
    max_quality_attempts=settings.max_quality_attempts,
    token_budget=settings.token_budget
)

standard_rag = StandardRAG(
    vector_store=vector_store,
    llm_service=llm_service,
    embeddings_service=embeddings_service
)

comparison_engine = ComparisonEngine(standard_rag, truecontext_rag)

# Create upload directory
os.makedirs(settings.upload_dir, exist_ok=True)


# Pydantic Models
class QueryRequest(BaseModel):
    query: str
    document_ids: List[str]
    model: str = "gpt-4.1-mini"
    top_k: Optional[int] = 10


class ChatMessage(BaseModel):
    message: str
    session_id: str
    document_ids: List[str]
    model: str = "gpt-4.1-mini"


# Health Check
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "ok",
        "timestamp": datetime.utcnow().isoformat(),
        "services": {
            "database": "ok",
            "vector_store": f"ok ({vector_store.get_stats()['total_vectors']} vectors)",
            "graph_store": "ok"
        }
    }


# Document Endpoints
@app.post("/documents/upload")
async def upload_document(
    file: UploadFile = File(...),
    document_type: str = Form("general")
):
    """Upload a document"""
    try:
        # Generate document ID
        doc_id = f"doc-{uuid.uuid4().hex[:12]}"
        
        # Get file extension
        filename = file.filename
        file_type = filename.split('.')[-1].lower()
        
        # Save file
        file_path = os.path.join(settings.upload_dir, f"{doc_id}.{file_type}")
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Get file size
        file_size = os.path.getsize(file_path)
        
        # Create database record
        doc_data = {
            'id': doc_id,
            'filename': filename,
            'file_type': file_type,
            'document_type': document_type,
            'upload_date': datetime.utcnow(),
            'processed': False,
            'status': 'uploaded',
            'file_path': file_path,
            'file_size': file_size,
            'metadata': {}
        }
        
        db_manager.create_document(doc_data)
        
        return {
            "document_id": doc_id,
            "filename": filename,
            "status": "uploaded",
            "message": "Document uploaded successfully. Call /documents/process/{document_id} to process."
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/documents/process/{document_id}")
async def process_document(document_id: str):
    """Process uploaded document"""
    try:
        # Get document
        doc = db_manager.get_document(document_id)
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Update status
        db_manager.update_document_status(document_id, "processing")
        
        # Extract text
        text = document_processor.extract_text(doc.file_path, doc.file_type)
        
        if not text.strip():
            db_manager.update_document_status(document_id, "error")
            raise HTTPException(status_code=400, detail="No text extracted from document")
        
        # Create chunks
        chunks = document_processor.create_contextual_chunks(
            text,
            {'filename': doc.filename, 'document_type': doc.document_type}
        )
        
        # Extract entities
        entities = document_processor.extract_entities_simple(text)
        
        # Generate embeddings
        chunk_texts = [c['enriched_text'] for c in chunks]
        embeddings = embeddings_service.embed_texts(chunk_texts)
        
        # Store in FAISS
        chunk_metadata = [
            {
                'id': f"chunk-{document_id}-{i}",
                'document_id': document_id,
                'chunk_index': c['chunk_index'],
                'text': c['text'],
                'tokens': c['tokens']
            }
            for i, c in enumerate(chunks)
        ]
        vector_store.add_embeddings(embeddings, chunk_metadata)
        
        # Store chunks in SQLite
        chunk_data = [
            {
                'id': f"chunk-{document_id}-{i}",
                'document_id': document_id,
                'chunk_index': c['chunk_index'],
                'text': c['text'],
                'enriched_text': c['enriched_text'],
                'tokens': c['tokens'],
                'embedding_id': f"chunk-{document_id}-{i}",
                'quality_score': 0.5,
                'section': document_processor._detect_section(c['text'], i)
            }
            for i, c in enumerate(chunks)
        ]
        db_manager.create_chunks(chunk_data)
        
        # Store entities in SQLite
        entity_data = [
            {
                'id': f"entity-{document_id}-{i}",
                'name': e['name'],
                'entity_type': e['type'],
                'value': e['value'],
                'confidence': e['confidence'],
                'document_id': document_id,
                'chunk_id': None
            }
            for i, e in enumerate(entities)
        ]
        db_manager.create_entities(entity_data)
        
        # Create graph nodes
        graph_store.create_document_node({
            'id': document_id,
            'filename': doc.filename,
            'type': doc.document_type,
            'upload_date': doc.upload_date.isoformat()
        })
        
        # Create chunk nodes
        for chunk in chunk_data:
            graph_store.create_chunk_node(chunk)
        
        # Link sequential chunks
        chunk_ids = [c['id'] for c in chunk_data]
        graph_store.link_sequential_chunks(chunk_ids)
        
        # Save vector index
        vector_store.save_index()
        
        # Update status
        db_manager.update_document_status(document_id, "indexed", processed=True)
        
        return {
            "document_id": document_id,
            "status": "indexed",
            "chunks_created": len(chunks),
            "entities_extracted": len(entities),
            "message": "Document processed successfully"
        }
    
    except Exception as e:
        db_manager.update_document_status(document_id, "error")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/documents")
async def list_documents():
    """List all documents"""
    docs = db_manager.list_documents()
    return {
        "documents": [
            {
                "id": doc.id,
                "filename": doc.filename,
                "type": doc.document_type,
                "status": doc.status,
                "processed": doc.processed,
                "upload_date": doc.upload_date.isoformat()
            }
            for doc in docs
        ]
    }


@app.delete("/documents/{document_id}")
async def delete_document(document_id: str):
    """Delete a document"""
    try:
        # Delete from database
        db_manager.delete_document(document_id)
        
        # Delete from graph
        graph_store.delete_document_graph(document_id)
        
        # Note: FAISS doesn't support deletion easily
        # In production, use a database that supports deletion
        
        return {"message": "Document deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# RAG Endpoints
@app.post("/rag/standard")
async def query_standard_rag(request: QueryRequest):
    """Query using standard RAG (baseline)"""
    try:
        result = await standard_rag.query(
            query=request.query,
            document_ids=request.document_ids,
            model=request.model,
            top_k=request.top_k
        )
        
        # Log query
        db_manager.create_query_log({
            'id': f"log-{uuid.uuid4().hex[:12]}",
            'query': request.query,
            'approach': 'standard',
            'model': request.model,
            'document_ids': request.document_ids,
            'response': result['response'],
            'quality_score': None,
            'quality_breakdown': None,
            'tokens_input': result['metrics']['tokens_input'],
            'tokens_output': result['metrics']['tokens_output'],
            'cost': result['metrics']['cost'],
            'latency': result['metrics']['latency']
        })
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/rag/truecontext")
async def query_truecontext_rag(request: QueryRequest):
    """Query using TrueContext RAG (our solution)"""
    try:
        result = await truecontext_rag.query(
            query=request.query,
            document_ids=request.document_ids,
            model=request.model
        )
        
        # Log query
        db_manager.create_query_log({
            'id': f"log-{uuid.uuid4().hex[:12]}",
            'query': request.query,
            'approach': 'truecontext',
            'model': request.model,
            'document_ids': request.document_ids,
            'response': result['response'],
            'quality_score': result['quality_score'],
            'quality_breakdown': result['quality_breakdown'],
            'tokens_input': result['metrics']['tokens_input'],
            'tokens_output': result['metrics']['tokens_output'],
            'cost': result['metrics']['cost'],
            'latency': result['metrics']['latency']
        })
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/rag/compare")
async def compare_rag_approaches(request: QueryRequest):
    """Compare Standard RAG vs TrueContext RAG"""
    try:
        result = await comparison_engine.compare(
            query=request.query,
            document_ids=request.document_ids,
            model=request.model
        )
        
        # Log comparison
        db_manager.create_comparison({
            'id': f"comp-{uuid.uuid4().hex[:12]}",
            'query': request.query,
            'standard_response': result['standard_rag'].get('response', ''),
            'truecontext_response': result['truecontext'].get('response', ''),
            'standard_metrics': result['standard_rag'].get('metrics', {}),
            'truecontext_metrics': result['truecontext'].get('metrics', {}),
            'winner': result['winner']
        })
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Models endpoint
@app.get("/models")
async def list_models():
    """List available LLM models"""
    return {
        "models": llm_service.get_available_models()
    }


# Quality metrics endpoint
@app.get("/quality/metrics")
async def get_quality_metrics():
    """Get quality metrics dashboard data"""
    logs = db_manager.get_query_logs(limit=50)
    
    truecontext_logs = [l for l in logs if l.approach == 'truecontext']
    standard_logs = [l for l in logs if l.approach == 'standard']
    
    return {
        "total_queries": len(logs),
        "truecontext": {
            "count": len(truecontext_logs),
            "avg_quality": sum(l.quality_score for l in truecontext_logs if l.quality_score) / len(truecontext_logs) if truecontext_logs else 0,
            "avg_cost": sum(l.cost for l in truecontext_logs) / len(truecontext_logs) if truecontext_logs else 0
        },
        "standard": {
            "count": len(standard_logs),
            "avg_cost": sum(l.cost for l in standard_logs) / len(standard_logs) if standard_logs else 0
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)