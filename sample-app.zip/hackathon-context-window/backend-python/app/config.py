"""
Configuration management for TrueContext AI backend
"""
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Azure OpenAI
    azure_openai_endpoint: str
    azure_openai_api_key: str
    azure_openai_deployment_gpt4_mini: str = "gpt-4.1-mini"
    azure_openai_deployment_gpt4o: str = "gpt-4o-mini"
    azure_openai_deployment_embedding: str = "text-embedding-3-small"
    azure_openai_api_version: str = "2024-02-15-preview"
    
    # OpenAI (fallback)
    openai_api_key: Optional[str] = None
    
    # Neo4j
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str
    
    # SQLite
    database_url: str = "sqlite:///./truecontext.db"
    
    # LangSmith
    langchain_tracing_v2: bool = True
    langchain_endpoint: str = "https://api.smith.langchain.com"
    langchain_api_key: Optional[str] = None
    langchain_project: str = "truecontext-ai"
    
    # App Settings
    max_upload_size_mb: int = 100
    token_budget: int = 100000
    quality_threshold: float = 0.85
    max_quality_attempts: int = 3
    
    # Paths
    upload_dir: str = "./data/uploads"
    faiss_indices_dir: str = "./data/faiss_indices"
    generated_quotes_dir: str = "./data/generated_quotes"
    
    class Config:
        env_file = ".env"
        case_sensitive = False


# Global settings instance
settings = Settings()