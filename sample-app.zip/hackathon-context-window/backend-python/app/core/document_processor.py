"""
Document Processor - Extract text from various file formats
"""
import PyPDF2
import docx
import pandas as pd
from typing import List, Dict, Tuple
import re
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class DocumentProcessor:
    """Process documents and extract structured information"""
    
    def __init__(self, chunk_size: int = 512):
        self.chunk_size = chunk_size
    
    def extract_text(self, file_path: str, file_type: str) -> str:
        """
        Extract text from file based on type
        
        Args:
            file_path: Path to file
            file_type: File extension (pdf, docx, csv, txt)
        
        Returns:
            Extracted text
        """
        try:
            if file_type == 'pdf':
                return self._extract_pdf(file_path)
            elif file_type == 'docx':
                return self._extract_docx(file_path)
            elif file_type == 'csv':
                return self._extract_csv(file_path)
            elif file_type == 'txt':
                return self._extract_txt(file_path)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
        except Exception as e:
            logger.error(f"Error extracting text from {file_path}: {e}")
            return ""
    
    def _extract_pdf(self, file_path: str) -> str:
        """Extract text from PDF"""
        text = []
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page in pdf_reader.pages:
                text.append(page.extract_text())
        return "\n\n".join(text)
    
    def _extract_docx(self, file_path: str) -> str:
        """Extract text from DOCX"""
        doc = docx.Document(file_path)
        text = []
        for para in doc.paragraphs:
            if para.text.strip():
                text.append(para.text)
        return "\n\n".join(text)
    
    def _extract_csv(self, file_path: str) -> str:
        """Extract text from CSV"""
        df = pd.read_csv(file_path)
        # Convert to readable text format
        text = f"CSV Data ({len(df)} rows, {len(df.columns)} columns)\n\n"
        text += df.to_string(index=False)
        return text
    
    def _extract_txt(self, file_path: str) -> str:
        """Extract text from TXT"""
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    
    def create_contextual_chunks(
        self,
        text: str,
        document_metadata: Dict
    ) -> List[Dict]:
        """
        Create chunks with prepended context (Anthropic-inspired)
        
        Args:
            text: Full document text
            document_metadata: Document metadata
        
        Returns:
            List of chunk dictionaries
        """
        # Split into paragraphs
        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        
        chunks = []
        current_chunk = []
        current_tokens = 0
        chunk_index = 0
        
        for para in paragraphs:
            para_tokens = len(para.split()) * 1.3  # Rough estimate
            
            if current_tokens + para_tokens > self.chunk_size and current_chunk:
                # Save current chunk
                chunk_text = "\n\n".join(current_chunk)
                enriched_text = self._enrich_chunk(
                    chunk_text, chunk_index, document_metadata
                )
                
                chunks.append({
                    'chunk_index': chunk_index,
                    'text': chunk_text,
                    'enriched_text': enriched_text,
                    'tokens': int(current_tokens)
                })
                
                chunk_index += 1
                current_chunk = [para]
                current_tokens = para_tokens
            else:
                current_chunk.append(para)
                current_tokens += para_tokens
        
        # Add final chunk
        if current_chunk:
            chunk_text = "\n\n".join(current_chunk)
            enriched_text = self._enrich_chunk(
                chunk_text, chunk_index, document_metadata
            )
            
            chunks.append({
                'chunk_index': chunk_index,
                'text': chunk_text,
                'enriched_text': enriched_text,
                'tokens': int(current_tokens)
            })
        
        logger.info(f"Created {len(chunks)} chunks from document")
        return chunks
    
    def _enrich_chunk(
        self,
        chunk_text: str,
        chunk_index: int,
        document_metadata: Dict
    ) -> str:
        """
        Prepend context to chunk (Anthropic contextual retrieval)
        
        Format:
        Document: [filename] | Type: [type] | Section: [section] |
        Chunk: [index] | Content: [text]
        """
        context_parts = [
            f"Document: {document_metadata.get('filename', 'Unknown')}",
            f"Type: {document_metadata.get('document_type', 'general')}",
            f"Section: {self._detect_section(chunk_text, chunk_index)}",
            f"Chunk: {chunk_index}"
        ]
        
        context = " | ".join(context_parts)
        enriched = f"{context}\n\nContent: {chunk_text}"
        
        return enriched
    
    def _detect_section(self, chunk_text: str, chunk_index: int) -> str:
        """Detect section from chunk text (simple heuristics)"""
        # Look for section headers
        first_line = chunk_text.split('\n')[0]
        
        # Common patterns
        if re.match(r'^#+\s+', first_line):  # Markdown headers
            return first_line.strip('#').strip()
        elif re.match(r'^[A-Z\s]+$', first_line) and len(first_line) < 50:  # ALL CAPS
            return first_line
        elif re.match(r'^\d+\.', first_line):  # Numbered sections
            return first_line.split('.', 1)[0] + "."
        else:
            return f"Section {chunk_index // 5 + 1}"  # Group every 5 chunks
    
    def extract_entities_simple(self, text: str) -> List[Dict]:
        """
        Simple entity extraction (regex-based)
        In production, use spaCy or LLM-based extraction
        """
        entities = []
        
        # Monetary amounts
        amounts = re.findall(r'\$[\d,]+(?:\.\d{2})?', text)
        for amount in amounts:
            entities.append({
                'name': amount,
                'type': 'amount',
                'value': amount,
                'confidence': 0.9
            })
        
        # Dates
        dates = re.findall(r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b', text)
        for date in dates:
            entities.append({
                'name': date,
                'type': 'date',
                'value': date,
                'confidence': 0.8
            })
        
        # Email addresses
        emails = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
        for email in emails:
            entities.append({
                'name': email,
                'type': 'email',
                'value': email,
                'confidence': 0.95
            })
        
        # Names (Title Case, 2+ words)
        names = re.findall(r'\b[A-Z][a-z]+ [A-Z][a-z]+(?:\s[A-Z][a-z]+)?\b', text)
        for name in names[:10]:  # Limit to avoid false positives
            entities.append({
                'name': name,
                'type': 'person',
                'value': name,
                'confidence': 0.7
            })
        
        return entities


# Singleton instance
document_processor = None

def get_document_processor(chunk_size: int = 512) -> DocumentProcessor:
    """Get or create document processor instance"""
    global document_processor
    if document_processor is None:
        document_processor = DocumentProcessor(chunk_size)
    return document_processor