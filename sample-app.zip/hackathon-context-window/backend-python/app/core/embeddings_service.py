"""
Embeddings Service - Azure OpenAI Text Embeddings
"""
from openai import AzureOpenAI
import numpy as np
from typing import List, Union
import logging

logger = logging.getLogger(__name__)


class EmbeddingsService:
    """Azure OpenAI embeddings service"""
    
    def __init__(
        self,
        azure_endpoint: str,
        api_key: str,
        deployment_name: str = "text-embedding-3-small",
        api_version: str = "2024-02-15-preview"
    ):
        self.client = AzureOpenAI(
            azure_endpoint=azure_endpoint,
            api_key=api_key,
            api_version=api_version
        )
        self.deployment_name = deployment_name
        self.dimension = 1536  # text-embedding-3-small dimension
    
    def embed_text(self, text: str) -> np.ndarray:
        """
        Embed a single text
        
        Args:
            text: Text to embed
        
        Returns:
            Numpy array of shape (1536,)
        """
        try:
            response = self.client.embeddings.create(
                model=self.deployment_name,
                input=text
            )
            embedding = response.data[0].embedding
            return np.array(embedding, dtype=np.float32)
        except Exception as e:
            logger.error(f"Embedding error: {e}")
            # Return zero vector as fallback
            return np.zeros(self.dimension, dtype=np.float32)
    
    def embed_texts(self, texts: List[str], batch_size: int = 100) -> np.ndarray:
        """
        Embed multiple texts in batches
        
        Args:
            texts: List of texts to embed
            batch_size: Batch size for API calls
        
        Returns:
            Numpy array of shape (n_texts, 1536)
        """
        all_embeddings = []
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            
            try:
                response = self.client.embeddings.create(
                    model=self.deployment_name,
                    input=batch
                )
                
                batch_embeddings = [item.embedding for item in response.data]
                all_embeddings.extend(batch_embeddings)
                
                logger.info(f"Embedded batch {i//batch_size + 1}/{(len(texts)-1)//batch_size + 1}")
            
            except Exception as e:
                logger.error(f"Batch embedding error: {e}")
                # Add zero vectors for failed batch
                all_embeddings.extend([np.zeros(self.dimension).tolist()] * len(batch))
        
        return np.array(all_embeddings, dtype=np.float32)
    
    def embed_query(self, query: str) -> np.ndarray:
        """
        Embed a query (alias for embed_text for clarity)
        
        Args:
            query: Query text
        
        Returns:
            Numpy array of shape (1536,)
        """
        return self.embed_text(query)
    
    def get_dimension(self) -> int:
        """Get embedding dimension"""
        return self.dimension


# Singleton instance
embeddings_service = None

def get_embeddings_service(
    azure_endpoint: str,
    api_key: str,
    deployment_name: str = "text-embedding-3-small"
) -> EmbeddingsService:
    """Get or create embeddings service instance"""
    global embeddings_service
    if embeddings_service is None:
        embeddings_service = EmbeddingsService(azure_endpoint, api_key, deployment_name)
    return embeddings_service