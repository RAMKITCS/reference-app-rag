"""
Standard RAG - Baseline Implementation
Simple semantic search + generation (no quality gates, no optimization)
"""
from typing import List, Dict, Tuple
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class StandardRAG:
    """
    Baseline RAG implementation for comparison
    
    Intentionally simple to highlight TrueContext improvements:
    - No quality validation
    - No budget optimization
    - No context enrichment
    - No adaptive retrieval
    """
    
    def __init__(
        self,
        vector_store,
        llm_service,
        embeddings_service
    ):
        self.vector_store = vector_store
        self.llm_service = llm_service
        self.embeddings_service = embeddings_service
    
    async def query(
        self,
        query: str,
        document_ids: List[str],
        model: str = "gpt-4.1-mini",
        top_k: int = 10
    ) -> Dict:
        """
        Execute standard RAG pipeline (baseline)
        
        Returns basic response without quality metrics
        """
        start_time = datetime.now()
        
        logger.info(f"Standard RAG query: {query}")
        
        # STEP 1: Query Embedding
        # No optimization, just embed the query as-is
        query_embedding = await self.embeddings_service.embed_query(query)
        
        # STEP 2: Semantic Search (FAISS only)
        # - No graph traversal
        # - No filtering
        # - Simple cosine similarity ranking
        # - Fixed top-K (no adaptation)
        chunks = await self.vector_store.search(
            query=query,
            document_ids=document_ids,
            top_k=top_k
        )
        
        logger.info(f"Retrieved {len(chunks)} chunks")
        
        # STEP 3: Context Assembly
        # - No optimization
        # - No deduplication
        # - Just concatenate in order
        # - May exceed context window (truncate if needed)
        context = self._simple_concatenate(chunks)
        
        # Count tokens (but don't optimize)
        tokens_context = self._rough_token_count(context)
        logger.info(f"Context tokens: {tokens_context}")
        
        # STEP 4: LLM Generation
        # - Simple prompt (no sophistication)
        # - No validation before generation
        # - No quality checking
        prompt = self._build_simple_prompt(query, context)
        
        response_text, generation_metrics = await self.llm_service.generate(
            prompt=prompt,
            model=model
        )
        
        # STEP 5: Return Basic Response
        # - No quality metrics
        # - No groundedness check
        # - No completeness validation
        # - Minimal metadata
        
        total_time = (datetime.now() - start_time).total_seconds()
        
        return {
            'response': response_text,
            'chunks_retrieved': len(chunks),
            'evidence': [
                {
                    'chunk_id': chunk['id'],
                    'source': chunk.get('metadata', {}).get('source', 'Unknown'),
                    'score': chunk.get('score', 0),
                    'text': chunk['text'][:200] + '...' if len(chunk['text']) > 200 else chunk['text']
                }
                for chunk in chunks
            ],
            'metrics': {
                'model': model,
                'tokens_input': generation_metrics['tokens_input'],
                'tokens_output': generation_metrics['tokens_output'],
                'cost': generation_metrics['cost'],
                'latency': total_time
            },
            # Missing from Standard RAG (present in TrueContext):
            # - quality_score
            # - quality_breakdown
            # - quality_attempts
            # - budget_used
            # - budget_utilization
            # - chunks_selected vs candidates
            # - confidence
            # - groundedness
            # - completeness
            # - optimization_metrics
        }
    
    def _simple_concatenate(self, chunks: List[Dict]) -> str:
        """
        Simple concatenation of chunks
        
        Issues (by design):
        - No ranking optimization
        - No redundancy removal
        - No coherence checking
        - No context enrichment
        """
        context_parts = []
        
        for idx, chunk in enumerate(chunks, 1):
            # Minimal formatting
            source = chunk.get('metadata', {}).get('source', 'Unknown')
            context_parts.append(f"[{idx}] {chunk['text']}")
        
        return "\n\n".join(context_parts)
    
    def _build_simple_prompt(self, query: str, context: str) -> str:
        """
        Basic prompt template
        
        Issues (by design):
        - No sophisticated instructions
        - No confidence calibration
        - No citation requirements
        - No validation instructions
        """
        return f"""Based on the following context, answer the question.

Context:
{context}

Question: {query}

Answer:"""
    
    def _rough_token_count(self, text: str) -> int:
        """
        Rough token estimate
        
        Standard RAG doesn't use precise token counting
        """
        return len(text.split()) * 1.3  # Rough approximation


class ComparisonEngine:
    """
    Execute both Standard and TrueContext RAG side-by-side
    Provides detailed comparison metrics
    """
    
    def __init__(
        self,
        standard_rag: StandardRAG,
        truecontext_rag
    ):
        self.standard_rag = standard_rag
        self.truecontext_rag = truecontext_rag
    
    async def compare(
        self,
        query: str,
        document_ids: List[str],
        model: str = "gpt-4.1-mini"
    ) -> Dict:
        """
        Execute both approaches in parallel and compare results
        """
        import asyncio
        
        logger.info(f"Starting side-by-side comparison for query: {query}")
        
        # Execute both in parallel
        standard_result, truecontext_result = await asyncio.gather(
            self.standard_rag.query(query, document_ids, model),
            self.truecontext_rag.query(query, document_ids, model),
            return_exceptions=True
        )
        
        # Handle exceptions
        if isinstance(standard_result, Exception):
            logger.error(f"Standard RAG failed: {standard_result}")
            standard_result = {'error': str(standard_result)}
        
        if isinstance(truecontext_result, Exception):
            logger.error(f"TrueContext RAG failed: {truecontext_result}")
            truecontext_result = {'error': str(truecontext_result)}
        
        # Analyze differences
        comparison_metrics = self._analyze_differences(
            query, standard_result, truecontext_result
        )
        
        return {
            'query': query,
            'standard_rag': standard_result,
            'truecontext': truecontext_result,
            'comparison': comparison_metrics,
            'winner': comparison_metrics.get('winner', 'tie')
        }
    
    def _analyze_differences(
        self,
        query: str,
        standard_result: Dict,
        truecontext_result: Dict
    ) -> Dict:
        """
        Analyze and quantify differences between approaches
        """
        # Handle errors
        if 'error' in standard_result or 'error' in truecontext_result:
            return {
                'winner': 'error',
                'notes': 'One or both approaches failed'
            }
        
        # Extract responses
        standard_response = standard_result.get('response', '')
        truecontext_response = truecontext_result.get('response', '')
        
        # 1. Completeness Analysis
        # What information did TrueContext include that Standard missed?
        standard_facts = self._extract_facts(standard_response)
        truecontext_facts = self._extract_facts(truecontext_response)
        
        missing_in_standard = [
            fact for fact in truecontext_facts
            if not self._fact_appears_in(fact, standard_facts)
        ]
        
        # 2. Accuracy Analysis
        # Check if responses cite sources properly
        standard_citations = standard_response.count('[Source') + standard_response.count('[1]')
        truecontext_citations = truecontext_response.count('[Source')
        
        # 3. Efficiency Analysis
        standard_tokens = standard_result.get('metrics', {}).get('tokens_input', 0)
        truecontext_tokens = truecontext_result.get('metrics', {}).get('tokens_input', 0)
        
        standard_cost = standard_result.get('metrics', {}).get('cost', 0)
        truecontext_cost = truecontext_result.get('metrics', {}).get('cost', 0)
        
        # 4. Quality Analysis (only TrueContext has this)
        quality_score = truecontext_result.get('quality_score', 0)
        quality_breakdown = truecontext_result.get('quality_breakdown', {})
        
        # 5. Calculate Winner
        # TrueContext wins if:
        # - Higher quality score
        # - More complete (fewer missing facts)
        # - Better citations
        # - Similar or better cost efficiency
        
        completeness_improvement = len(missing_in_standard) / max(len(truecontext_facts), 1)
        citation_improvement = (truecontext_citations - standard_citations) / max(standard_citations, 1)
        
        # Token efficiency: quality per token
        truecontext_efficiency = quality_score / max(truecontext_tokens, 1)
        
        # Determine winner
        if quality_score >= 0.85 and completeness_improvement > 0.2:
            winner = 'truecontext'
            confidence = 'high'
        elif quality_score >= 0.75 and completeness_improvement > 0.1:
            winner = 'truecontext'
            confidence = 'medium'
        else:
            winner = 'tie'
            confidence = 'low'
        
        return {
            'winner': winner,
            'confidence': confidence,
            'completeness': {
                'facts_in_standard': len(standard_facts),
                'facts_in_truecontext': len(truecontext_facts),
                'missing_in_standard': missing_in_standard[:5],  # Top 5
                'improvement_pct': round(completeness_improvement * 100, 1)
            },
            'citations': {
                'standard': standard_citations,
                'truecontext': truecontext_citations,
                'improvement': citation_improvement
            },
            'efficiency': {
                'standard_tokens': standard_tokens,
                'truecontext_tokens': truecontext_tokens,
                'standard_cost': round(standard_cost, 4),
                'truecontext_cost': round(truecontext_cost, 4),
                'token_savings_pct': round((1 - truecontext_tokens / max(standard_tokens, 1)) * 100, 1),
                'cost_savings_pct': round((1 - truecontext_cost / max(standard_cost, 0.0001)) * 100, 1)
            },
            'quality': {
                'truecontext_score': quality_score,
                'truecontext_breakdown': quality_breakdown,
                'standard_score': 'N/A (no quality validation)'
            },
            'latency': {
                'standard': round(standard_result.get('metrics', {}).get('latency', 0), 2),
                'truecontext': round(truecontext_result.get('metrics', {}).get('latency', 0), 2)
            },
            'summary': self._generate_comparison_summary(
                winner, completeness_improvement, quality_score
            )
        }
    
    def _extract_facts(self, text: str) -> List[str]:
        """
        Extract factual statements from text
        Simple sentence-based extraction (can be enhanced with NLP)
        """
        # Split into sentences
        sentences = []
        for sentence in text.split('.'):
            sentence = sentence.strip()
            if len(sentence) > 20:  # Minimum length for a fact
                sentences.append(sentence)
        
        return sentences
    
    def _fact_appears_in(self, fact: str, fact_list: List[str]) -> bool:
        """
        Check if a fact (or very similar fact) appears in list
        """
        fact_lower = fact.lower()
        fact_words = set(fact_lower.split())
        
        for existing_fact in fact_list:
            existing_words = set(existing_fact.lower().split())
            # If 70%+ word overlap, consider it the same fact
            overlap = len(fact_words & existing_words) / len(fact_words)
            if overlap >= 0.7:
                return True
        
        return False
    
    def _generate_comparison_summary(
        self,
        winner: str,
        completeness_improvement: float,
        quality_score: float
    ) -> str:
        """Generate human-readable comparison summary"""
        if winner == 'truecontext':
            return (
                f"TrueContext AI delivered superior results with "
                f"{int(completeness_improvement * 100)}% more complete information "
                f"and {int(quality_score * 100)}% overall quality score. "
                f"Quality gates ensured high-confidence answers with proper source citations."
            )
        elif winner == 'tie':
            return (
                "Both approaches delivered similar results for this query. "
                "TrueContext's quality validation confirmed context sufficiency."
            )
        else:
            return "Comparison inconclusive."