"""
TrueContext RAG - Quality-First Retrieval Augmented Generation
Combines quality validation, budget optimization, and adaptive retrieval
"""
from typing import List, Dict, Tuple, Optional
import numpy as np
from datetime import datetime
import logging

from .quality_validator import QualityValidator, QualityDimensions
from .budget_optimizer import BudgetOptimizer

logger = logging.getLogger(__name__)


class TrueContextRAG:
    """
    Main TrueContext RAG pipeline with quality gates and budget optimization
    """
    
    def __init__(
        self,
        vector_store,
        graph_store,
        llm_service,
        embeddings_service,
        quality_threshold: float = 0.85,
        max_quality_attempts: int = 3,
        token_budget: int = 100000
    ):
        self.vector_store = vector_store
        self.graph_store = graph_store
        self.llm_service = llm_service
        self.embeddings_service = embeddings_service
        
        self.quality_validator = QualityValidator()
        self.budget_optimizer = BudgetOptimizer(token_budget=token_budget)
        
        self.quality_threshold = quality_threshold
        self.max_quality_attempts = max_quality_attempts
        self.token_budget = token_budget
    
    async def query(
        self,
        query: str,
        document_ids: List[str],
        model: str = "gpt-4.1-mini",
        user_profile: Optional[Dict] = None,
        conversation_history: Optional[List[Dict]] = None
    ) -> Dict:
        """
        Execute TrueContext RAG pipeline
        
        Returns comprehensive response with quality metrics
        """
        start_time = datetime.now()
        
        # STEP 1: Query Classification & Planning
        query_analysis = self._analyze_query(query)
        logger.info(f"Query classified as: {query_analysis['type']}")
        
        # STEP 2: Context Graph Retrieval (Hybrid)
        candidates, candidate_embeddings = await self._hybrid_retrieval(
            query, document_ids, query_analysis
        )
        logger.info(f"Retrieved {len(candidates)} candidate chunks")
        
        # STEP 3: Budget Optimization
        query_embedding = await self.embeddings_service.embed_query(query)
        optimized_chunks, optimization_metrics = self.budget_optimizer.optimize_selection(
            candidates=candidates,
            embeddings=candidate_embeddings,
            query_embedding=query_embedding,
            token_budget=self.token_budget,
            user_profile=user_profile
        )
        logger.info(f"Optimized to {len(optimized_chunks)} chunks")
        
        # STEP 4: Quality Gate Assessment (with retries)
        quality_attempt = 0
        quality_passed = False
        quality_dimensions = None
        quality_diagnostics = None
        
        while quality_attempt < self.max_quality_attempts and not quality_passed:
            quality_attempt += 1
            
            # Get embeddings for optimized chunks
            optimized_embeddings = np.array([
                candidate_embeddings[next(
                    i for i, c in enumerate(candidates) if c['id'] == chunk['id']
                )]
                for chunk in optimized_chunks
            ])
            
            # Validate quality
            quality_dimensions, quality_diagnostics = self.quality_validator.validate_context(
                query=query,
                chunks=optimized_chunks,
                embeddings=optimized_embeddings,
                estimated_response_tokens=query_analysis['estimated_response_tokens']
            )
            
            logger.info(
                f"Quality attempt {quality_attempt}: "
                f"Score={quality_dimensions.overall_score():.3f}"
            )
            
            # Check if quality threshold met
            if quality_dimensions.overall_score() >= self.quality_threshold:
                quality_passed = True
                logger.info("Quality gate passed!")
            else:
                # Diagnose and adapt
                deficiencies = quality_dimensions.get_deficiencies(self.quality_threshold)
                suggestions = self.quality_validator.get_improvement_suggestions(
                    quality_dimensions, quality_diagnostics
                )
                
                logger.warning(
                    f"Quality gate failed. Deficiencies: {deficiencies}. "
                    f"Attempting adaptation..."
                )
                
                # Adapt retrieval based on deficiencies
                if quality_attempt < self.max_quality_attempts:
                    candidates, candidate_embeddings = await self._adapt_retrieval(
                        query=query,
                        document_ids=document_ids,
                        current_chunks=optimized_chunks,
                        deficiencies=deficiencies,
                        suggestions=suggestions
                    )
                    
                    # Re-optimize with expanded candidates
                    optimized_chunks, optimization_metrics = self.budget_optimizer.optimize_selection(
                        candidates=candidates,
                        embeddings=candidate_embeddings,
                        query_embedding=query_embedding,
                        token_budget=self.token_budget,
                        user_profile=user_profile
                    )
        
        # If still not passing after max attempts, proceed anyway but flag it
        if not quality_passed:
            logger.warning(
                f"Quality threshold not met after {self.max_quality_attempts} attempts. "
                f"Proceeding with best available context (score={quality_dimensions.overall_score():.3f})"
            )
        
        # STEP 5: Generate Response
        response_text, generation_metrics = await self._generate_response(
            query=query,
            chunks=optimized_chunks,
            model=model,
            conversation_history=conversation_history
        )
        
        # STEP 6: Response Validation
        validation_results = self._validate_response(
            response=response_text,
            chunks=optimized_chunks,
            query=query
        )
        
        # Calculate total time
        total_time = (datetime.now() - start_time).total_seconds()
        
        # STEP 7: Compile Enhanced Response
        return {
            'response': response_text,
            'quality_score': quality_dimensions.overall_score(),
            'quality_breakdown': quality_dimensions.to_dict(),
            'quality_passed': quality_passed,
            'quality_attempts': quality_attempt,
            'budget_used': optimization_metrics['tokens_used'],
            'budget_total': self.token_budget,
            'budget_utilization': optimization_metrics['budget_utilization'],
            'chunks_selected': len(optimized_chunks),
            'chunks_candidates': optimization_metrics['candidates_total'],
            'confidence': validation_results['confidence'],
            'groundedness': validation_results['groundedness'],
            'completeness': validation_results['completeness'],
            'evidence': [
                {
                    'chunk_id': chunk['id'],
                    'source': chunk.get('metadata', {}).get('source', 'Unknown'),
                    'score': chunk.get('score', 0),
                    'score_breakdown': chunk.get('score_breakdown', {}),
                    'text': chunk['text'][:200] + '...' if len(chunk['text']) > 200 else chunk['text']
                }
                for chunk in optimized_chunks
            ],
            'metrics': {
                'model': model,
                'tokens_input': generation_metrics['tokens_input'],
                'tokens_output': generation_metrics['tokens_output'],
                'cost': generation_metrics['cost'],
                'latency': total_time
            },
            'query_analysis': query_analysis,
            'quality_diagnostics': quality_diagnostics,
            'optimization_metrics': optimization_metrics
        }
    
    def _analyze_query(self, query: str) -> Dict:
        """
        Classify query and estimate resource requirements
        """
        # Simple heuristics (can be replaced with ML classifier)
        query_lower = query.lower()
        word_count = len(query.split())
        
        # Classify query type
        if any(word in query_lower for word in ['what', 'who', 'when', 'where']):
            query_type = 'factual'
            estimated_response = 200
        elif any(word in query_lower for word in ['why', 'how', 'explain']):
            query_type = 'analytical'
            estimated_response = 500
        elif any(word in query_lower for word in ['compare', 'analyze', 'evaluate', 'comprehensive']):
            query_type = 'comprehensive'
            estimated_response = 1000
        else:
            query_type = 'general'
            estimated_response = 300
        
        # Adjust based on query length
        if word_count > 20:
            estimated_response = int(estimated_response * 1.5)
        
        # Determine complexity
        if word_count < 10 and query_type == 'factual':
            complexity = 'simple'
        elif word_count > 25 or query_type == 'comprehensive':
            complexity = 'complex'
        else:
            complexity = 'medium'
        
        return {
            'type': query_type,
            'complexity': complexity,
            'word_count': word_count,
            'estimated_response_tokens': estimated_response
        }
    
    async def _hybrid_retrieval(
        self,
        query: str,
        document_ids: List[str],
        query_analysis: Dict
    ) -> Tuple[List[Dict], np.ndarray]:
        """
        Hybrid retrieval: Vector search + Graph traversal
        """
        # Determine retrieval parameters based on query complexity
        if query_analysis['complexity'] == 'simple':
            top_k_vector = 20
            graph_hops = 1
        elif query_analysis['complexity'] == 'complex':
            top_k_vector = 50
            graph_hops = 2
        else:
            top_k_vector = 30
            graph_hops = 1
        
        # Vector search (FAISS)
        vector_results = await self.vector_store.search(
            query=query,
            document_ids=document_ids,
            top_k=top_k_vector
        )
        
        # Graph traversal (Neo4j)
        graph_results = await self.graph_store.traverse(
            query=query,
            document_ids=document_ids,
            max_hops=graph_hops
        )
        
        # Fusion: Combine and deduplicate
        all_chunks = {}
        all_embeddings = []
        
        # Add vector results
        for result in vector_results:
            chunk_id = result['id']
            if chunk_id not in all_chunks:
                all_chunks[chunk_id] = {
                    **result,
                    'retrieval_method': 'vector'
                }
                all_embeddings.append(result['embedding'])
        
        # Add graph results
        for result in graph_results:
            chunk_id = result['id']
            if chunk_id not in all_chunks:
                # Need to get embedding for graph-retrieved chunks
                embedding = await self.embeddings_service.embed_text(result['text'])
                all_chunks[chunk_id] = {
                    **result,
                    'retrieval_method': 'graph',
                    'embedding': embedding
                }
                all_embeddings.append(embedding)
            else:
                # Mark as retrieved by both methods (high confidence)
                all_chunks[chunk_id]['retrieval_method'] = 'hybrid'
                # Boost score for hybrid retrieval
                all_chunks[chunk_id]['score'] = min(
                    1.0,
                    all_chunks[chunk_id].get('score', 0.5) * 1.2
                )
        
        candidates = list(all_chunks.values())
        embeddings = np.array(all_embeddings)
        
        return candidates, embeddings
    
    async def _adapt_retrieval(
        self,
        query: str,
        document_ids: List[str],
        current_chunks: List[Dict],
        deficiencies: List[str],
        suggestions: List[Dict]
    ) -> Tuple[List[Dict], np.ndarray]:
        """
        Adapt retrieval strategy based on quality deficiencies
        """
        additional_chunks = []
        additional_embeddings = []
        
        for suggestion in suggestions:
            action = suggestion['action']
            
            if action == 'expand_retrieval':
                # Increase graph traversal depth
                expanded_results = await self.graph_store.traverse(
                    query=query,
                    document_ids=document_ids,
                    max_hops=3  # Deeper traversal
                )
                for result in expanded_results:
                    if result['id'] not in {c['id'] for c in current_chunks}:
                        embedding = await self.embeddings_service.embed_text(result['text'])
                        additional_chunks.append({**result, 'embedding': embedding})
                        additional_embeddings.append(embedding)
            
            elif action == 'retrieve_surrounding_context':
                # Fetch chunks before/after current chunks
                for chunk in current_chunks:
                    surrounding = await self.graph_store.get_surrounding_chunks(
                        chunk_id=chunk['id'],
                        context_window=2  # 2 chunks before and after
                    )
                    for result in surrounding:
                        if result['id'] not in {c['id'] for c in current_chunks}:
                            embedding = await self.embeddings_service.embed_text(result['text'])
                            additional_chunks.append({**result, 'embedding': embedding})
                            additional_embeddings.append(embedding)
            
            elif action == 'expand_query':
                # Query expansion with synonyms/related terms
                expanded_queries = self._expand_query(query)
                for exp_query in expanded_queries:
                    exp_results = await self.vector_store.search(
                        query=exp_query,
                        document_ids=document_ids,
                        top_k=10
                    )
                    for result in exp_results:
                        if result['id'] not in {c['id'] for c in current_chunks}:
                            additional_chunks.append(result)
                            additional_embeddings.append(result['embedding'])
        
        # Combine current and additional chunks
        all_chunks = current_chunks + additional_chunks
        
        # Get all embeddings
        current_embeddings = np.array([
            c.get('embedding', await self.embeddings_service.embed_text(c['text']))
            for c in current_chunks
        ])
        
        if additional_embeddings:
            all_embeddings = np.vstack([current_embeddings, np.array(additional_embeddings)])
        else:
            all_embeddings = current_embeddings
        
        return all_chunks, all_embeddings
    
    def _expand_query(self, query: str) -> List[str]:
        """
        Simple query expansion (can be enhanced with word embeddings)
        """
        # Synonym map (simplified - in production, use WordNet or word2vec)
        synonyms = {
            'insurance': ['coverage', 'policy', 'protection'],
            'quote': ['estimate', 'pricing', 'premium'],
            'claim': ['loss', 'incident', 'damage'],
            'policy': ['coverage', 'contract', 'agreement']
        }
        
        expanded = [query]
        query_words = query.lower().split()
        
        for word in query_words:
            if word in synonyms:
                for synonym in synonyms[word]:
                    expanded.append(query.replace(word, synonym))
        
        return expanded[:3]  # Limit to avoid too many queries
    
    async def _generate_response(
        self,
        query: str,
        chunks: List[Dict],
        model: str,
        conversation_history: Optional[List[Dict]] = None
    ) -> Tuple[str, Dict]:
        """
        Generate response using LLM with validated context
        """
        # Build context
        context = self._build_context(chunks)
        
        # Build prompt
        prompt = self._build_prompt(query, context, conversation_history)
        
        # Call LLM
        response, metrics = await self.llm_service.generate(
            prompt=prompt,
            model=model
        )
        
        return response, metrics
    
    def _build_context(self, chunks: List[Dict]) -> str:
        """Build formatted context from chunks"""
        context_parts = []
        
        for idx, chunk in enumerate(chunks, 1):
            source = chunk.get('metadata', {}).get('source', 'Unknown')
            context_parts.append(
                f"[Source {idx}: {source}]\n{chunk['text']}\n"
            )
        
        return "\n".join(context_parts)
    
    def _build_prompt(
        self,
        query: str,
        context: str,
        conversation_history: Optional[List[Dict]] = None
    ) -> str:
        """Build optimized prompt for LLM"""
        prompt_parts = [
            "You are analyzing documents to answer questions accurately.",
            "",
            "Context (validated, high-quality):",
            context,
            "",
            f"Question: {query}",
            "",
            "Instructions:",
            "- Answer based ONLY on the provided context",
            "- Cite specific sources for each claim (use [Source N])",
            "- If uncertain, state your confidence level",
            "- If information is insufficient, clearly state what's missing",
            "",
            "Answer:"
        ]
        
        if conversation_history:
            history_str = "\n".join([
                f"{msg['role']}: {msg['content']}"
                for msg in conversation_history[-3:]  # Last 3 turns
            ])
            prompt_parts.insert(2, f"Conversation History:\n{history_str}\n")
        
        return "\n".join(prompt_parts)
    
    def _validate_response(
        self,
        response: str,
        chunks: List[Dict],
        query: str
    ) -> Dict:
        """
        Validate generated response for groundedness and completeness
        """
        # Groundedness: Check if facts are from sources
        chunk_texts = [c['text'].lower() for c in chunks]
        response_lower = response.lower()
        
        # Simple fact extraction (can be enhanced with NLP)
        response_sentences = response.split('.')
        grounded_count = 0
        
        for sentence in response_sentences:
            if len(sentence.strip()) < 10:
                continue
            # Check if sentence content appears in sources
            words = set(sentence.lower().split())
            for chunk_text in chunk_texts:
                chunk_words = set(chunk_text.split())
                overlap = len(words & chunk_words) / len(words) if words else 0
                if overlap > 0.3:  # 30% word overlap threshold
                    grounded_count += 1
                    break
        
        groundedness = grounded_count / len(response_sentences) if response_sentences else 0
        
        # Completeness: Did we answer all parts of the query?
        query_words = set(query.lower().split())
        response_words = set(response.lower().split())
        coverage = len(query_words & response_words) / len(query_words) if query_words else 0
        
        # Confidence: Based on citation count and hedging language
        citation_count = response.count('[Source')
        hedging_words = ['might', 'could', 'possibly', 'unclear', 'uncertain']
        hedging_count = sum(1 for word in hedging_words if word in response_lower)
        
        # Higher confidence with more citations and fewer hedges
        confidence = min(1.0, (citation_count * 0.1) + (1.0 - hedging_count * 0.1))
        confidence = max(0.5, confidence)  # Floor at 0.5
        
        return {
            'groundedness': groundedness,
            'completeness': coverage,
            'confidence': confidence,
            'citation_count': citation_count
        }