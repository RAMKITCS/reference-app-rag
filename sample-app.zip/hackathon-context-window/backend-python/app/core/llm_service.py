"""
LLM Service - Multi-model support with Azure OpenAI
"""
from openai import AzureOpenAI
from typing import Dict, Tuple, List
import tiktoken
import logging

logger = logging.getLogger(__name__)


class LLMService:
    """LLM service with multiple model support"""
    
    # Cost per 1K tokens (as of Dec 2024)
    PRICING = {
        "gpt-4.1-mini": {"input": 0.00015, "output": 0.00060},
        "gpt-4o-mini": {"input": 0.00015, "output": 0.00060},
        "gpt-4-turbo": {"input": 0.01, "output": 0.03},
        "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015}
    }
    
    def __init__(
        self,
        azure_endpoint: str,
        api_key: str,
        api_version: str = "2024-02-15-preview"
    ):
        self.client = AzureOpenAI(
            azure_endpoint=azure_endpoint,
            api_key=api_key,
            api_version=api_version
        )
        self.tokenizer = tiktoken.encoding_for_model("gpt-4")
    
    async def generate(
        self,
        prompt: str,
        model: str = "gpt-4.1-mini",
        temperature: float = 0.7,
        max_tokens: int = 2000,
        messages: List[Dict] = None
    ) -> Tuple[str, Dict]:
        """
        Generate response using LLM
        
        Args:
            prompt: Prompt text (used if messages not provided)
            model: Model deployment name
            temperature: Sampling temperature
            max_tokens: Maximum output tokens
            messages: Chat messages (optional, overrides prompt)
        
        Returns:
            Tuple of (response_text, metrics_dict)
        """
        # Build messages
        if messages is None:
            messages = [{"role": "user", "content": prompt}]
        
        # Count input tokens
        input_text = "\n".join([m["content"] for m in messages])
        tokens_input = self._count_tokens(input_text)
        
        try:
            # Call API
            response = self.client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            # Extract response
            response_text = response.choices[0].message.content
            tokens_output = response.usage.completion_tokens
            
            # Calculate cost
            cost = self._calculate_cost(model, tokens_input, tokens_output)
            
            metrics = {
                "model": model,
                "tokens_input": tokens_input,
                "tokens_output": tokens_output,
                "tokens_total": tokens_input + tokens_output,
                "cost": cost,
                "finish_reason": response.choices[0].finish_reason
            }
            
            logger.info(f"Generated response: {tokens_output} tokens, ${cost:.4f}")
            
            return response_text, metrics
        
        except Exception as e:
            logger.error(f"Generation error: {e}")
            return f"Error: {str(e)}", {
                "model": model,
                "tokens_input": tokens_input,
                "tokens_output": 0,
                "tokens_total": tokens_input,
                "cost": 0,
                "error": str(e)
            }
    
    def _count_tokens(self, text: str) -> int:
        """Count tokens in text"""
        try:
            return len(self.tokenizer.encode(text))
        except:
            # Fallback: rough estimate
            return int(len(text.split()) * 1.3)
    
    def _calculate_cost(self, model: str, tokens_input: int, tokens_output: int) -> float:
        """Calculate cost for API call"""
        pricing = self.PRICING.get(model, self.PRICING["gpt-4.1-mini"])
        
        cost_input = (tokens_input / 1000) * pricing["input"]
        cost_output = (tokens_output / 1000) * pricing["output"]
        
        return cost_input + cost_output
    
    def get_available_models(self) -> List[Dict]:
        """Get list of available models with metadata"""
        return [
            {
                "id": "gpt-4.1-mini",
                "name": "GPT-4.1 Mini (Azure)",
                "provider": "azure",
                "cost_per_1k_input": self.PRICING["gpt-4.1-mini"]["input"],
                "cost_per_1k_output": self.PRICING["gpt-4.1-mini"]["output"],
                "context_window": 128000,
                "recommended_for": "Fast queries, high volume",
                "description": "Fastest and most cost-effective"
            },
            {
                "id": "gpt-4o-mini",
                "name": "GPT-4o Mini (Azure)",
                "provider": "azure",
                "cost_per_1k_input": self.PRICING["gpt-4o-mini"]["input"],
                "cost_per_1k_output": self.PRICING["gpt-4o-mini"]["output"],
                "context_window": 128000,
                "recommended_for": "Balanced performance",
                "description": "Good balance of speed and quality"
            },
            {
                "id": "gpt-4-turbo",
                "name": "GPT-4 Turbo (Azure)",
                "provider": "azure",
                "cost_per_1k_input": self.PRICING["gpt-4-turbo"]["input"],
                "cost_per_1k_output": self.PRICING["gpt-4-turbo"]["output"],
                "context_window": 128000,
                "recommended_for": "Complex analysis",
                "description": "Most capable model"
            }
        ]


# Singleton instance
llm_service = None

def get_llm_service(
    azure_endpoint: str,
    api_key: str
) -> LLMService:
    """Get or create LLM service instance"""
    global llm_service
    if llm_service is None:
        llm_service = LLMService(azure_endpoint, api_key)
    return llm_service