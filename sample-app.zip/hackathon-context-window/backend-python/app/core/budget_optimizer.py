"""
Budget Optimizer - Intelligent Token Allocation
Greedy Knapsack algorithm for optimal chunk selection
"""
from typing import List, Dict, Tuple
import numpy as np
from dataclasses import dataclass
import tiktoken


@dataclass
class ChunkScore:
    """Scoring components for a single chunk"""
    chunk_id: str
    utility: float  # Semantic relevance (0-1)
    diversity: float  # Novelty vs already-selected (0-1)
    recency: float  # Temporal freshness (0-1)
    profile: float  # User role alignment (0-1)
    influence: float  # Historical usefulness (0-1)
    tokens: int
    
    def composite_score(self, weights: Dict[str, float] = None) -> float:
        """Calculate weighted composite score"""
        if weights is None:
            weights = {
                'utility': 0.5,
                'diversity': 0.2,
                'recency': 0.1,
                'profile': 0.1,
                'influence': 0.1
            }
        
        return (
            weights['utility'] * self.utility +
            weights['diversity'] * self.diversity +
            weights['recency'] * self.recency +
            weights['profile'] * self.profile +
            weights['influence'] * self.influence
        )
    
    def efficiency(self, weights: Dict[str, float] = None) -> float:
        """Score per token (efficiency ratio)"""
        score = self.composite_score(weights)
        return score / self.tokens if self.tokens > 0 else 0


class BudgetOptimizer:
    """
    Optimizes chunk selection within token budget
    Implements greedy knapsack algorithm with multi-dimensional scoring
    """
    
    def __init__(self, token_budget: int = 100000):
        self.token_budget = token_budget
        self.tokenizer = tiktoken.encoding_for_model("gpt-4")
        self.selected_embeddings = []  # Track selected for diversity calculation
    
    def optimize_selection(
        self,
        candidates: List[Dict],
        embeddings: np.ndarray,
        query_embedding: np.ndarray,
        token_budget: int = None,
        user_profile: Dict = None,
        historical_usage: Dict = None
    ) -> Tuple[List[Dict], Dict]:
        """
        Select optimal subset of chunks within budget
        
        Args:
            candidates: List of candidate chunks with metadata
            embeddings: Numpy array of chunk embeddings (n_chunks, dim)
            query_embedding: Query embedding vector (1, dim)
            token_budget: Token limit (overrides default)
            user_profile: User role/preferences for profile scoring
            historical_usage: Historical chunk usefulness data
        
        Returns:
            Tuple of (selected_chunks, optimization_metrics)
        """
        budget = token_budget or self.token_budget
        
        # Step 1: Calculate scores for all candidates
        chunk_scores = self._calculate_chunk_scores(
            candidates, embeddings, query_embedding, user_profile, historical_usage
        )
        
        # Step 2: Sort by efficiency (score/token ratio)
        chunk_scores.sort(key=lambda x: x.efficiency(), reverse=True)
        
        # Step 3: Greedy selection
        selected = []
        selected_indices = []
        total_tokens = 0
        self.selected_embeddings = []
        
        for idx, chunk_score in enumerate(chunk_scores):
            # Check if adding this chunk would exceed budget
            if total_tokens + chunk_score.tokens <= budget:
                # Find original chunk
                chunk = next(
                    (c for c in candidates if c['id'] == chunk_score.chunk_id),
                    None
                )
                
                if chunk:
                    selected.append({
                        **chunk,
                        'score_breakdown': {
                            'utility': chunk_score.utility,
                            'diversity': chunk_score.diversity,
                            'recency': chunk_score.recency,
                            'profile': chunk_score.profile,
                            'influence': chunk_score.influence,
                            'composite': chunk_score.composite_score(),
                            'efficiency': chunk_score.efficiency()
                        }
                    })
                    selected_indices.append(
                        next(i for i, c in enumerate(candidates) if c['id'] == chunk_score.chunk_id)
                    )
                    total_tokens += chunk_score.tokens
                    
                    # Track embedding for diversity calculation
                    self.selected_embeddings.append(
                        embeddings[next(i for i, c in enumerate(candidates) if c['id'] == chunk_score.chunk_id)]
                    )
        
        # Calculate optimization metrics
        metrics = {
            'candidates_total': len(candidates),
            'chunks_selected': len(selected),
            'tokens_used': total_tokens,
            'tokens_budget': budget,
            'budget_utilization': total_tokens / budget if budget > 0 else 0,
            'avg_efficiency': np.mean([cs.efficiency() for cs in chunk_scores[:len(selected)]]),
            'avg_utility': np.mean([s['score_breakdown']['utility'] for s in selected]),
            'avg_diversity': np.mean([s['score_breakdown']['diversity'] for s in selected]),
            'selection_rate': len(selected) / len(candidates) if candidates else 0
        }
        
        return selected, metrics
    
    def _calculate_chunk_scores(
        self,
        candidates: List[Dict],
        embeddings: np.ndarray,
        query_embedding: np.ndarray,
        user_profile: Dict = None,
        historical_usage: Dict = None
    ) -> List[ChunkScore]:
        """Calculate multi-dimensional scores for all candidates"""
        scores = []
        
        for idx, chunk in enumerate(candidates):
            chunk_embedding = embeddings[idx].reshape(1, -1)
            
            # 1. Utility: Semantic relevance to query
            utility = self._calculate_utility(chunk_embedding, query_embedding, chunk)
            
            # 2. Diversity: Novelty vs already-selected chunks
            diversity = self._calculate_diversity(chunk_embedding)
            
            # 3. Recency: Temporal freshness
            recency = self._calculate_recency(chunk)
            
            # 4. Profile: Alignment with user role/preferences
            profile = self._calculate_profile_match(chunk, user_profile)
            
            # 5. Influence: Historical usefulness
            influence = self._calculate_influence(chunk, historical_usage)
            
            # Count tokens
            tokens = self._count_tokens(chunk['text'])
            
            scores.append(ChunkScore(
                chunk_id=chunk['id'],
                utility=utility,
                diversity=diversity,
                recency=recency,
                profile=profile,
                influence=influence,
                tokens=tokens
            ))
        
        return scores
    
    def _calculate_utility(
        self, chunk_embedding: np.ndarray, query_embedding: np.ndarray, chunk: Dict
    ) -> float:
        """
        Utility = Semantic relevance to query
        Uses cosine similarity from embedding space
        """
        # Cosine similarity (already computed in chunk['score'] from retrieval)
        base_similarity = chunk.get('score', 0.5)
        
        # Boost for exact keyword matches
        query_text = chunk.get('query', '').lower()
        chunk_text = chunk.get('text', '').lower()
        
        query_words = set(query_text.split())
        chunk_words = set(chunk_text.split())
        
        keyword_overlap = len(query_words & chunk_words) / len(query_words) if query_words else 0
        keyword_boost = 0.1 * keyword_overlap
        
        utility = min(1.0, base_similarity + keyword_boost)
        return float(utility)
    
    def _calculate_diversity(self, chunk_embedding: np.ndarray) -> float:
        """
        Diversity = Novelty compared to already-selected chunks
        Higher diversity means more novel information
        """
        if not self.selected_embeddings:
            return 1.0  # First chunk is maximally diverse
        
        # Calculate similarity to all selected chunks
        from sklearn.metrics.pairwise import cosine_similarity
        similarities = cosine_similarity(
            chunk_embedding,
            np.array(self.selected_embeddings)
        )[0]
        
        # Diversity = 1 - max_similarity (most similar existing chunk)
        max_similarity = np.max(similarities)
        diversity = 1.0 - max_similarity
        
        return float(diversity)
    
    def _calculate_recency(self, chunk: Dict) -> float:
        """
        Recency = Temporal freshness of information
        More recent information scores higher
        """
        metadata = chunk.get('metadata', {})
        
        # Try to extract date from metadata or chunk
        date_field = metadata.get('date') or metadata.get('created_at')
        
        if not date_field:
            return 0.5  # Neutral if no date available
        
        # Parse date and calculate age in days
        from datetime import datetime
        try:
            if isinstance(date_field, str):
                chunk_date = datetime.fromisoformat(date_field.replace('Z', '+00:00'))
            else:
                chunk_date = date_field
            
            age_days = (datetime.now() - chunk_date).days
            
            # Score: 1.0 for today, decreasing exponentially
            # Half-life of 365 days (1 year)
            recency = np.exp(-age_days / 365.0)
            return float(recency)
        except:
            return 0.5
    
    def _calculate_profile_match(self, chunk: Dict, user_profile: Dict = None) -> float:
        """
        Profile = Alignment with user role/preferences
        Matches chunk content to user's expertise level and domain
        """
        if not user_profile:
            return 0.5  # Neutral if no profile
        
        score = 0.5
        
        # Match expertise level
        user_expertise = user_profile.get('expertise_level', 'intermediate')
        chunk_metadata = chunk.get('metadata', {})
        chunk_complexity = chunk_metadata.get('complexity', 'intermediate')
        
        complexity_map = {'basic': 0, 'intermediate': 1, 'advanced': 2}
        expertise_match = 1.0 - abs(
            complexity_map.get(user_expertise, 1) - complexity_map.get(chunk_complexity, 1)
        ) / 2.0
        
        score += 0.3 * expertise_match
        
        # Match domain/industry
        user_domain = user_profile.get('domain', '').lower()
        chunk_domain = chunk_metadata.get('domain', '').lower()
        
        if user_domain and chunk_domain and user_domain == chunk_domain:
            score += 0.2
        
        return min(1.0, score)
    
    def _calculate_influence(self, chunk: Dict, historical_usage: Dict = None) -> float:
        """
        Influence = Historical usefulness of this chunk
        Based on past query success rates
        """
        if not historical_usage:
            return 0.5  # Neutral if no history
        
        chunk_id = chunk['id']
        
        # Get historical metrics for this chunk
        chunk_history = historical_usage.get(chunk_id, {})
        
        times_used = chunk_history.get('times_used', 0)
        success_rate = chunk_history.get('success_rate', 0.5)  # % of successful queries
        
        # Influence = success_rate * log(1 + times_used)
        # More usage with high success = higher influence
        usage_factor = np.log1p(times_used) / np.log1p(100)  # Normalize to 100 uses
        influence = success_rate * (0.5 + 0.5 * usage_factor)
        
        return float(influence)
    
    def _count_tokens(self, text: str) -> int:
        """Count tokens in text"""
        try:
            return len(self.tokenizer.encode(text))
        except:
            # Fallback estimate
            return int(len(text.split()) * 1.3)
    
    def adaptive_budget_allocation(
        self,
        query_complexity: str,  # 'simple', 'medium', 'complex'
        conversation_context: int = 0,  # tokens of conversation history
        total_budget: int = None
    ) -> Dict[str, int]:
        """
        Dynamically allocate token budget across components
        
        Returns budget allocation dict:
        {
            'query_and_immediate': int,
            'document_chunks': int,
            'conversation_history': int,
            'user_profile': int
        }
        """
        budget = total_budget or self.token_budget
        
        # Base allocations by query complexity
        allocations = {
            'simple': {
                'query_and_immediate': 0.30,
                'document_chunks': 0.50,
                'conversation_history': 0.15,
                'user_profile': 0.05
            },
            'medium': {
                'query_and_immediate': 0.35,
                'document_chunks': 0.45,
                'conversation_history': 0.15,
                'user_profile': 0.05
            },
            'complex': {
                'query_and_immediate': 0.40,
                'document_chunks': 0.35,
                'conversation_history': 0.20,
                'user_profile': 0.05
            }
        }
        
        allocation = allocations.get(query_complexity, allocations['medium'])
        
        # Adjust if conversation is long
        if conversation_context > 5000:
            # Reduce document chunks, increase conversation
            allocation['document_chunks'] -= 0.10
            allocation['conversation_history'] += 0.10
        
        # Convert percentages to token counts
        token_allocation = {
            key: int(budget * value)
            for key, value in allocation.items()
        }
        
        return token_allocation