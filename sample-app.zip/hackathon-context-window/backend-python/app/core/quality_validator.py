"""
Quality Validator - 6-Dimension Quality Assessment System
This is the core innovation of TrueContext AI
"""
from typing import List, Dict, Tuple
from dataclasses import dataclass
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import tiktoken
import re
from datetime import datetime


@dataclass
class QualityDimensions:
    """Quality assessment scores for retrieved context"""
    coverage: float  # Are all required entities present?
    coherence: float  # Do chunks form logical narrative?
    sufficiency: float  # Is context 3x response size?
    distribution: float  # Are relevance scores well-distributed?
    redundancy: float  # How much duplicate information?
    temporal: float  # Is timeline coherent?
    
    def overall_score(self) -> float:
        """Calculate weighted overall quality score"""
        weights = {
            'coverage': 0.25,
            'coherence': 0.20,
            'sufficiency': 0.25,
            'distribution': 0.10,
            'redundancy': 0.10,
            'temporal': 0.10
        }
        return (
            weights['coverage'] * self.coverage +
            weights['coherence'] * self.coherence +
            weights['sufficiency'] * self.sufficiency +
            weights['distribution'] * self.distribution +
            weights['redundancy'] * self.redundancy +
            weights['temporal'] * self.temporal
        )
    
    def to_dict(self) -> Dict[str, float]:
        """Convert to dictionary for JSON serialization"""
        return {
            'coverage': round(self.coverage, 3),
            'coherence': round(self.coherence, 3),
            'sufficiency': round(self.sufficiency, 3),
            'distribution': round(self.distribution, 3),
            'redundancy': round(self.redundancy, 3),
            'temporal': round(self.temporal, 3),
            'overall': round(self.overall_score(), 3)
        }
    
    def get_deficiencies(self, threshold: float = 0.85) -> List[str]:
        """Identify which dimensions are below threshold"""
        deficiencies = []
        if self.coverage < threshold:
            deficiencies.append('coverage')
        if self.coherence < 0.75:  # Lower threshold for coherence
            deficiencies.append('coherence')
        if self.sufficiency < 0.80:  # Lower threshold for sufficiency
            deficiencies.append('sufficiency')
        if self.distribution < 0.70:  # Lower threshold for distribution
            deficiencies.append('distribution')
        if self.redundancy > 0.15:  # Inverted - high redundancy is bad
            deficiencies.append('redundancy')
        if self.temporal < threshold:
            deficiencies.append('temporal')
        return deficiencies


class QualityValidator:
    """
    Validates context quality BEFORE LLM generation
    Implements 6-dimension quality assessment
    """
    
    def __init__(self, embedding_model: str = "text-embedding-3-small"):
        self.embedding_model = embedding_model
        self.tokenizer = tiktoken.encoding_for_model("gpt-4")
    
    def validate_context(
        self,
        query: str,
        chunks: List[Dict],
        embeddings: np.ndarray,
        estimated_response_tokens: int = 500
    ) -> Tuple[QualityDimensions, Dict[str, any]]:
        """
        Comprehensive quality validation of retrieved context
        
        Args:
            query: User query string
            chunks: List of chunk dictionaries with 'text', 'score', 'metadata'
            embeddings: Numpy array of chunk embeddings (n_chunks, embedding_dim)
            estimated_response_tokens: Expected response size
        
        Returns:
            Tuple of (QualityDimensions, diagnostics_dict)
        """
        
        # Calculate each dimension
        coverage_score, coverage_diag = self._assess_coverage(query, chunks)
        coherence_score, coherence_diag = self._assess_coherence(embeddings)
        sufficiency_score, sufficiency_diag = self._assess_sufficiency(
            chunks, estimated_response_tokens
        )
        distribution_score, distribution_diag = self._assess_distribution(chunks)
        redundancy_score, redundancy_diag = self._assess_redundancy(embeddings, chunks)
        temporal_score, temporal_diag = self._assess_temporal(chunks)
        
        # Combine diagnostics
        diagnostics = {
            'coverage': coverage_diag,
            'coherence': coherence_diag,
            'sufficiency': sufficiency_diag,
            'distribution': distribution_diag,
            'redundancy': redundancy_diag,
            'temporal': temporal_diag
        }
        
        dimensions = QualityDimensions(
            coverage=coverage_score,
            coherence=coherence_score,
            sufficiency=sufficiency_score,
            distribution=distribution_score,
            redundancy=redundancy_score,
            temporal=temporal_score
        )
        
        return dimensions, diagnostics
    
    def _assess_coverage(self, query: str, chunks: List[Dict]) -> Tuple[float, Dict]:
        """
        Dimension 1: Coverage
        Are all required entities from the query present in chunks?
        """
        # Extract entities from query (simple NER)
        query_entities = self._extract_entities(query)
        
        if not query_entities:
            return 1.0, {'entities_required': 0, 'entities_found': 0, 'missing': []}
        
        # Check which entities appear in chunks
        chunk_text = " ".join([c['text'] for c in chunks])
        entities_found = [e for e in query_entities if e.lower() in chunk_text.lower()]
        
        coverage = len(entities_found) / len(query_entities) if query_entities else 1.0
        
        diagnostics = {
            'entities_required': len(query_entities),
            'entities_found': len(entities_found),
            'missing': [e for e in query_entities if e not in entities_found],
            'found': entities_found
        }
        
        return coverage, diagnostics
    
    def _assess_coherence(self, embeddings: np.ndarray) -> Tuple[float, Dict]:
        """
        Dimension 2: Coherence
        Do chunks form a logical narrative? (pairwise similarity)
        """
        if len(embeddings) < 2:
            return 1.0, {'chunk_count': len(embeddings), 'pairwise_similarities': []}
        
        # Calculate pairwise cosine similarities
        similarities = cosine_similarity(embeddings)
        
        # Get upper triangle (excluding diagonal)
        n = len(similarities)
        upper_triangle = similarities[np.triu_indices(n, k=1)]
        
        if len(upper_triangle) == 0:
            return 1.0, {'chunk_count': n, 'pairwise_similarities': []}
        
        coherence = float(np.mean(upper_triangle))
        
        diagnostics = {
            'chunk_count': n,
            'mean_similarity': round(coherence, 3),
            'std_similarity': round(float(np.std(upper_triangle)), 3),
            'min_similarity': round(float(np.min(upper_triangle)), 3),
            'max_similarity': round(float(np.max(upper_triangle)), 3)
        }
        
        return coherence, diagnostics
    
    def _assess_sufficiency(
        self, chunks: List[Dict], estimated_response_tokens: int
    ) -> Tuple[float, Dict]:
        """
        Dimension 3: Sufficiency
        Is context 3x the expected response size?
        """
        total_tokens = sum([self._count_tokens(c['text']) for c in chunks])
        target_tokens = 3 * estimated_response_tokens
        
        # Score: 1.0 if >= target, proportional if less
        sufficiency = min(1.0, total_tokens / target_tokens) if target_tokens > 0 else 1.0
        
        diagnostics = {
            'context_tokens': total_tokens,
            'target_tokens': target_tokens,
            'ratio': round(total_tokens / target_tokens, 2) if target_tokens > 0 else 0,
            'estimated_response_tokens': estimated_response_tokens
        }
        
        return sufficiency, diagnostics
    
    def _assess_distribution(self, chunks: List[Dict]) -> Tuple[float, Dict]:
        """
        Dimension 4: Distribution
        Are relevance scores well-spread or clustered?
        """
        if not chunks or len(chunks) < 2:
            return 1.0, {'chunk_count': len(chunks), 'scores': []}
        
        scores = [c.get('score', 0.5) for c in chunks]
        mean_score = np.mean(scores)
        std_score = np.std(scores)
        
        # Good distribution: moderate std relative to mean
        # Bad distribution: very low std (all similar) or very high std (polarized)
        if mean_score == 0:
            return 0.5, {'mean': 0, 'std': std_score, 'scores': scores}
        
        coefficient_of_variation = std_score / mean_score
        
        # Optimal CV is around 0.3-0.5
        # Score: 1.0 if CV in optimal range, decreasing otherwise
        if 0.3 <= coefficient_of_variation <= 0.5:
            distribution = 1.0
        elif coefficient_of_variation < 0.3:
            distribution = coefficient_of_variation / 0.3
        else:
            distribution = max(0.5, 0.5 / (coefficient_of_variation - 0.4))
        
        diagnostics = {
            'mean_score': round(mean_score, 3),
            'std_score': round(std_score, 3),
            'coefficient_of_variation': round(coefficient_of_variation, 3),
            'scores': [round(s, 3) for s in scores]
        }
        
        return distribution, diagnostics
    
    def _assess_redundancy(
        self, embeddings: np.ndarray, chunks: List[Dict]
    ) -> Tuple[float, Dict]:
        """
        Dimension 5: Redundancy
        How much duplicate/near-duplicate information?
        Lower redundancy is better (inverted scoring)
        """
        if len(embeddings) < 2:
            return 1.0, {'duplicate_pairs': 0, 'total_pairs': 0}
        
        # Find near-duplicate pairs (similarity > 0.95)
        similarities = cosine_similarity(embeddings)
        n = len(similarities)
        
        duplicate_count = 0
        total_pairs = 0
        duplicate_pairs = []
        
        for i in range(n):
            for j in range(i + 1, n):
                total_pairs += 1
                if similarities[i, j] > 0.95:
                    duplicate_count += 1
                    duplicate_pairs.append((i, j, round(similarities[i, j], 3)))
        
        redundancy_ratio = duplicate_count / total_pairs if total_pairs > 0 else 0
        
        # Score: 1.0 if no redundancy, decreasing with more duplicates
        # Target: < 15% redundancy
        if redundancy_ratio < 0.15:
            score = 1.0
        else:
            score = max(0.0, 1.0 - (redundancy_ratio - 0.15) / 0.85)
        
        diagnostics = {
            'duplicate_pairs': duplicate_count,
            'total_pairs': total_pairs,
            'redundancy_ratio': round(redundancy_ratio, 3),
            'duplicate_indices': duplicate_pairs[:5]  # Top 5
        }
        
        return score, diagnostics
    
    def _assess_temporal(self, chunks: List[Dict]) -> Tuple[float, Dict]:
        """
        Dimension 6: Temporal Coherence
        Is the timeline coherent? Do date sequences make sense?
        """
        dates = []
        for idx, chunk in enumerate(chunks):
            chunk_dates = self._extract_dates(chunk['text'])
            for date_str, parsed_date in chunk_dates:
                dates.append({
                    'chunk_idx': idx,
                    'date_str': date_str,
                    'parsed': parsed_date
                })
        
        if len(dates) < 2:
            return 1.0, {'dates_found': len(dates), 'coherence': 'N/A'}
        
        # Check if dates are in reasonable order (allowing some flexibility)
        sorted_dates = sorted(dates, key=lambda x: x['parsed'])
        
        # Calculate how many dates are "out of order" compared to chunk order
        out_of_order = 0
        for i in range(len(sorted_dates) - 1):
            if sorted_dates[i]['chunk_idx'] > sorted_dates[i + 1]['chunk_idx']:
                out_of_order += 1
        
        coherence = 1.0 - (out_of_order / (len(sorted_dates) - 1))
        
        diagnostics = {
            'dates_found': len(dates),
            'out_of_order_count': out_of_order,
            'timeline': [
                {
                    'chunk': d['chunk_idx'],
                    'date': d['date_str'],
                    'parsed': d['parsed'].isoformat()
                }
                for d in sorted_dates[:10]  # First 10
            ]
        }
        
        return coherence, diagnostics
    
    def _extract_entities(self, text: str) -> List[str]:
        """
        Simple entity extraction (NER)
        In production, use spaCy or similar NLP library
        """
        # Patterns for common entities
        patterns = [
            r'\b[A-Z][a-z]+ [A-Z][a-z]+\b',  # Names (Title Case)
            r'\$[\d,]+(?:\.\d{2})?',  # Monetary amounts
            r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b',  # Dates
            r'\b[A-Z]{2,}\b',  # Acronyms
        ]
        
        entities = set()
        for pattern in patterns:
            matches = re.findall(pattern, text)
            entities.update(matches)
        
        return list(entities)
    
    def _extract_dates(self, text: str) -> List[Tuple[str, datetime]]:
        """
        Extract dates from text
        Returns list of (date_string, parsed_datetime) tuples
        """
        date_patterns = [
            (r'\b\d{1,2}/\d{1,2}/\d{4}\b', '%m/%d/%Y'),
            (r'\b\d{4}-\d{2}-\d{2}\b', '%Y-%m-%d'),
            (r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \d{1,2},? \d{4}\b', '%B %d, %Y'),
        ]
        
        dates = []
        for pattern, date_format in date_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                try:
                    parsed = datetime.strptime(match, date_format)
                    dates.append((match, parsed))
                except:
                    continue
        
        return dates
    
    def _count_tokens(self, text: str) -> int:
        """Count tokens in text using tiktoken"""
        try:
            return len(self.tokenizer.encode(text))
        except:
            # Fallback: rough estimate
            return len(text.split()) * 1.3
    
    def get_improvement_suggestions(
        self, dimensions: QualityDimensions, diagnostics: Dict
    ) -> List[Dict[str, str]]:
        """
        Generate actionable suggestions for improving quality
        """
        suggestions = []
        
        if dimensions.coverage < 0.85:
            missing = diagnostics['coverage'].get('missing', [])
            suggestions.append({
                'dimension': 'coverage',
                'issue': f"Missing {len(missing)} required entities",
                'action': 'expand_retrieval',
                'details': f"Expand graph traversal to find: {', '.join(missing[:3])}"
            })
        
        if dimensions.coherence < 0.75:
            suggestions.append({
                'dimension': 'coherence',
                'issue': "Chunks lack narrative coherence",
                'action': 'retrieve_surrounding_context',
                'details': "Fetch surrounding chunks to improve flow"
            })
        
        if dimensions.sufficiency < 0.80:
            target = diagnostics['sufficiency']['target_tokens']
            current = diagnostics['sufficiency']['context_tokens']
            suggestions.append({
                'dimension': 'sufficiency',
                'issue': f"Insufficient context ({current} / {target} tokens)",
                'action': 'increase_budget',
                'details': f"Retrieve {target - current} more tokens"
            })
        
        if dimensions.distribution < 0.70:
            cv = diagnostics['distribution']['coefficient_of_variation']
            if cv < 0.3:
                suggestions.append({
                    'dimension': 'distribution',
                    'issue': "Relevance scores too similar (low variance)",
                    'action': 'expand_query',
                    'details': "Use query expansion to find more diverse chunks"
                })
            else:
                suggestions.append({
                    'dimension': 'distribution',
                    'issue': "Relevance scores too polarized",
                    'action': 'adjust_retrieval_params',
                    'details': "Adjust similarity threshold"
                })
        
        if dimensions.redundancy > 0.15:
            dup_count = diagnostics['redundancy']['duplicate_pairs']
            suggestions.append({
                'dimension': 'redundancy',
                'issue': f"{dup_count} near-duplicate chunks found",
                'action': 'deduplicate',
                'details': "Remove redundant chunks to save tokens"
            })
        
        if dimensions.temporal < 0.85:
            out_of_order = diagnostics['temporal'].get('out_of_order_count', 0)
            suggestions.append({
                'dimension': 'temporal',
                'issue': f"{out_of_order} dates out of chronological order",
                'action': 'sort_by_timeline',
                'details': "Re-order chunks chronologically"
            })
        
        return suggestions